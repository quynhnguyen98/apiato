<?php

namespace App\Containers\PhanQuyen\Tasks;

use App\Containers\PhanQuyen\Data\Repositories\PhanQuyenModelRepository;
use App\Containers\PhanQuyen\Models\PhanQuyenModel;
use App\Ship\Exceptions\DeleteResourceFailedException;
use App\Ship\Parents\Tasks\Task;

class DeletePhanQuyenTask extends Task
{
    protected $repository;
    public function __construct(PhanQuyenModelRepository $repository)
    {
        $this->repository=$repository;
    }

    public function run(PhanQuyenModel $model)
    {

      try {
        $this->repository->delete($model->id);
      }
      catch (Exception $exception) {
        throw new DeleteResourceFailedException();
      }
    }
}

<?php

namespace App\Containers\PhanQuyen\Tasks;

use App\Containers\PhanQuyen\Data\Repositories\PhanQuyenModelRepository;
use App\Containers\PhanQuyen\Models\PhanQuyenModel;
use App\Ship\Parents\Tasks\Task;

class CreatePhanQuyenTask extends Task
{
    protected $repository;
    public function __construct(PhanQuyenModelRepository $repository)
    {
        $this->repository=$repository;
    }

    public function run(string $name,string $guard_name,string $display_name,string $description):PhanQuyenModel
    {
        $arr=$this->repository->create([
          'name'=>$name,
          'guard_name'=>$guard_name,
          'display_name'=>$display_name,
          'description'=>$description
        ]);
        return $arr;
    }
}

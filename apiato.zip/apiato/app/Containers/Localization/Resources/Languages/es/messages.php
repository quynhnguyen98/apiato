<?php

return [

    'welcome' => 'Bienvenido a Apiato',

];

<?php

/**
 * @apiDefine GeneralAcceptedResponse
 * @apiSuccessExample {json} Success-Response:
HTTP/1.1 202 Accepted
{
}
 */

<?php

return [

    'welcome' => 'Welcome to Apiato (GB)',

];

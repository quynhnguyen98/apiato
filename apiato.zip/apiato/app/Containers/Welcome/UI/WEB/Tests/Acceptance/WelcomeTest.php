<?php
//
//namespace App\Containers\Welcome\UI\WEB\Tests\Acceptance;
//
//use App\Ship\Parents\Tests\PhpUnit\TestCase;
//
///**
// * Class WelcomeTest.
// *
// * @group welcome
// * @group web
// *
// * @author Mahmoud Zalt <mahmoud@zalt.me>
// */
//class WelcomeTest extends TestCase
//{
//
//    private $page = '/';
//
//    /**
//     * @test
//     */
//    public function testDisplayWelcomeView()
//    {
//        $this->visit($this->page)
//            ->see('apiato');
//    }
//}

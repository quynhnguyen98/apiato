<?php

namespace App\Containers\PhanQuyen\Models;

use App\Ship\Parents\Models\Model;

class PhanQuyenModel extends Model
{
    protected $table='permissions';
    protected $fillable = [
      'id',
      'name',
      'guard_name',
      'display_name',
      'description'
    ];
    public $timestamps=false;

    protected $attributes = [

    ];

    protected $hidden = [

    ];

    protected $casts = [

    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    /**
     * A resource key to be used by the the JSON API Serializer responses.
     */
    protected $resourceKey = 'phanquyenmodels';
}

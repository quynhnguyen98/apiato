<?php

namespace App\Containers\Authorization\Tests;

use App\Containers\Authorization\Tests\TestCase as BaseTestCase;

/**
 * Class ApiTestCase.
 *
 * This is the container API TestCase class. Use this class to add your container specific API related helper functions.
 */
class ApiTestCase extends BaseTestCase
{
    // ..
}

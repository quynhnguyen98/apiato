<?php

namespace App\Containers\Stripe\Tests;

use App\Containers\Stripe\Tests\TestCase as BaseTestCase;

/**
 * Class ApiTestCase.
 *
 * This is the container API TestCase class. Use this class to add your container specific API related helper functions.
 */
class ApiTestCase extends BaseTestCase
{
    // ..
}

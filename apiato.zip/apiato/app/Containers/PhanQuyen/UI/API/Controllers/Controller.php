<?php

namespace App\Containers\PhanQuyen\UI\API\Controllers;

use Apiato\Core\Foundation\Facades\Apiato;

use App\Containers\PhanQuyen\Actions\CreatePhanQuyenAction;
use App\Containers\PhanQuyen\Actions\DeletePhanQuyenAction;
use App\Containers\PhanQuyen\Actions\EditPhanQuyenAction;
use App\Containers\PhanQuyen\Actions\FindPhanQuyenAction;
use App\Containers\PhanQuyen\Actions\GetAllPhanQuyenAction;
use App\Containers\PhanQuyen\UI\API\Requests\CreatePhanQuyenRequest;
use App\Containers\PhanQuyen\UI\API\Requests\EditPhanQuyenRequest;
use App\Containers\PhanQuyen\UI\API\Requests\FindPhanQuyenRequest;
use App\Containers\User\UI\API\Requests\DeleteUserRequest;
use App\Ship\Parents\Controllers\ApiController;

class Controller extends ApiController
{
  public function getAllPhanQuyen()
  {
    $list=Apiato::call(GetAllPhanQuyenAction::class);
    return $this->json($list);
  }

  public function createPhanQuyen(CreatePhanQuyenRequest $request)
  {
    $insert=Apiato::call(CreatePhanQuyenAction::class,[$request]);
    return $this->json($insert);
  }

  public function getIDPhanQuyen(FindPhanQuyenRequest $request)
  {
    $getId=Apiato::call(FindPhanQuyenAction::class,[$request]);
    return $this->json($getId);
  }

  public function deletePhanQuyen(DeleteUserRequest $request)
  {
    $del=Apiato::call(DeletePhanQuyenAction::class,[$request]);
    return $this->noContent();

  }
  public function updatePhanQuyen(EditPhanQuyenRequest $request)
  {
    $update=Apiato::call(EditPhanQuyenAction::class,[$request]);
    return $this->json($update);
  }
}

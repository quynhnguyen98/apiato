<?php

namespace App\Ship\Parents\Commands;

use Apiato\Core\Abstracts\Commands\ConsoleCommand as AbstractConsoleCommand;

/**
 * Class ConsoleCommand
 *
 * @author  Mahmoud Zalt  <mahmoud@zalt.me>
 */
abstract class ConsoleCommand extends AbstractConsoleCommand
{

}

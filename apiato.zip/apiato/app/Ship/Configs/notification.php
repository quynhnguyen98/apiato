<?php

return [

    /*
     |--------------------------------------------------------------------------
     | Default Namespace
     |--------------------------------------------------------------------------
     |
     | Define what channels does all your notifications support.
     |
     */
    'channels' => [
        'database',
//        'mail',
    ]

];

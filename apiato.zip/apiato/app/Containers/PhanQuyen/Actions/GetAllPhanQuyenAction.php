<?php

namespace App\Containers\PhanQuyen\Actions;

use App\Containers\PhanQuyen\Tasks\GetAllPhanQuyenTask;
use App\Ship\Parents\Actions\Action;
use Apiato\Core\Foundation\Facades\Apiato;

class GetAllPhanQuyenAction extends Action
{
    public function run()
    {
        // $var = Apiato::call('Container@Task', [$arg1, $arg2, ...]);
      $list=Apiato::call(GetAllPhanQuyenTask::class);
      return $list;
    }
}

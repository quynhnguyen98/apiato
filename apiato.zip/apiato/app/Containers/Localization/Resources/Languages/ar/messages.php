<?php

return [

    'welcome' => 'أهلا بك في Apiato',

];

<?php

namespace App\Ship\Parents\Actions;

use Apiato\Core\Abstracts\Actions\SubAction as AbstractSubAction;

/**
 * Class SubAction.
 *
 * @author  Mahmoud Zalt <mahmoud@zalt.me>
 */
abstract class SubAction extends AbstractSubAction
{

}

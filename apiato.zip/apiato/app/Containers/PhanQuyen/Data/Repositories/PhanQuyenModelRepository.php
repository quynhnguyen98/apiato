<?php

namespace App\Containers\PhanQuyen\Data\Repositories;

use App\Ship\Parents\Repositories\Repository;

/**
 * Class PhanQuyenModelRepository
 */
class PhanQuyenModelRepository extends Repository
{

    /**
     * @var array
     */
    protected $fieldSearchable = [
        'id' => '=',
        'name'=>'like',
        'guard_name'=>'=',
        'display_name'=>'like',
        'description'=>'like'
      // ...
    ];

}

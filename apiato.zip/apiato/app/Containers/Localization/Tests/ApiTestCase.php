<?php

namespace App\Containers\Localization\Tests;

use App\Containers\Localization\Tests\TestCase as BaseTestCase;

/**
 * Class ApiTestCase.
 *
 * This is the container API TestCase class. Use this class to add your container specific API related helper functions.
 */
class ApiTestCase extends BaseTestCase
{
    // ..
}

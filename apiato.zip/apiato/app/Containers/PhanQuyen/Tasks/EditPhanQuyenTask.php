<?php

namespace App\Containers\PhanQuyen\Tasks;

use App\Containers\PhanQuyen\Data\Repositories\PhanQuyenModelRepository;
use App\Containers\PhanQuyen\Models\PhanQuyenModel;
use App\Ship\Parents\Tasks\Task;

class EditPhanQuyenTask extends Task
{
  protected $repository;
    public function __construct(PhanQuyenModelRepository $repository)
    {
      $this->repository=$repository;
    }

    public function run($arr,$id):PhanQuyenModel
    {
      $update=$this->repository->update($arr,$id);
      return $update;
    }
}

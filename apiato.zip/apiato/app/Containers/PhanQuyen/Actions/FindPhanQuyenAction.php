<?php

namespace App\Containers\PhanQuyen\Actions;

use App\Containers\PhanQuyen\Models\PhanQuyenModel;
use App\Containers\PhanQuyen\Tasks\FindPhanQuyenTask;
use App\Ship\Parents\Actions\Action;
use Apiato\Core\Foundation\Facades\Apiato;
use App\Ship\Parents\Requests\Request;
use App\Ship\Transporters\DataTransporter;

class FindPhanQuyenAction extends Action
{
    public function run(DataTransporter $request):PhanQuyenModel
    {
        // $var = Apiato::call('Container@Task', [$arg1, $arg2, ...]);
      $getId=Apiato::call(FindPhanQuyenTask::class,[$request->id]);
      return $getId;
    }
}

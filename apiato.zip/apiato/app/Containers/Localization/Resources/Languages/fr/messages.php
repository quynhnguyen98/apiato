<?php

return [

    'welcome' => 'Bienvenue chez Apiato',

];

<?php

namespace App\Containers\PhanQuyen\Actions;

use Apiato\Core\Providers\ApiatoProvider;
use App\Containers\PhanQuyen\Models\PhanQuyenModel;
use App\Containers\PhanQuyen\Tasks\CreatePhanQuyenTask;
use App\Ship\Parents\Actions\Action;
use Apiato\Core\Foundation\Facades\Apiato;
use App\Ship\Parents\Requests\Request;
use App\Ship\Transporters\DataTransporter;
use Facade\FlareClient\Api;

class CreatePhanQuyenAction extends Action
{
    public function run(Request $data):PhanQuyenModel
    {
        // $var = Apiato::call('Container@Task', [$arg1, $arg2, ...]);
//      'id',
//      'name',
//      'guard_name',
//      'display_name',
//      'description'
      $insert=Apiato::call(CreatePhanQuyenTask::class,[
        $data->name,
        $data->guard_name,
        $data->display_name,
        $data->description
      ]);
      return $insert;
    }
}

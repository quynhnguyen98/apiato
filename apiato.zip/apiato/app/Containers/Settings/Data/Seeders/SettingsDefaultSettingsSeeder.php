<?php

namespace App\Containers\Settings\Data\Seeders;

use App\Ship\Parents\Seeders\Seeder;

/**
 * Class SettingsDefaultSettingsSeeder
 *
 * @author  Mahmoud Zalt  <mahmoud@zalt.me>
 */
class SettingsDefaultSettingsSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        $settings = new Settings();
//        $settings->key = 'referring_user_points';
//        $settings->value = '200';
//        $settings->save();
//
//        $settings = new Settings();
//        $settings->key = 'referred_user_points';
//        $settings->value = '200';
//        $settings->save();
    }
}

<?php

// For this file to be registered you need to edit the commands function in `app/Ship/kernel/ShipConsoleKernel.php`.

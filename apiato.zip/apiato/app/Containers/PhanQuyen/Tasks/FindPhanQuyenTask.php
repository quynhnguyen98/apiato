<?php

namespace App\Containers\PhanQuyen\Tasks;

use App\Containers\PhanQuyen\Data\Repositories\PhanQuyenModelRepository;
use App\Containers\PhanQuyen\Models\PhanQuyenModel;
use App\Ship\Parents\Tasks\Task;

class FindPhanQuyenTask extends Task
{
    protected $repository;
    public function __construct(PhanQuyenModelRepository $repository)
    {
        $this->repository=$repository;
    }

    public function run($id):PhanQuyenModel
    {
        $find_id=$this->repository->find($id);
        return $find_id;
    }
}
